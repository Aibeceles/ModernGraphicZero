/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MainClass;

/**
 *
 * @author Aibes
 */

import LoopLists.GaussBean1;
import LoopLists.LoopList;
import PArrayReset.PolynomialArray;
import fractionintegerset.FractionIntegerDriver;
import fractionintegerset.FractionIntegerDriverIterate;
import fractionintegerset.muNumDen;
import mucorrolationthreaded.*;
import java.beans.*;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Aibes
 */

public class GaussTable1 extends Thread {
    private Semaphore tlSem;  
    public static final String PROP_SAMPLE_PROPERTY = "sampleProperty";
    private String sampleProperty;
    private PropertyChangeSupport propertySupport;
    private String framework = "embedded";
//    private String driver = "org.apache.derby.jdbc.EmbeddedDriver";
//    private String protocol = "jdbc:derby:";
 
//    private String driver = "com.mysql.jdbc.Driver";
//    private String protocol = "jdbc:mysql://localhost:3306/";
    
    private String driver = "org.neo4j:neo4j-jdbc-driver:3.3.0";
    private String protocol = "jdbc:neo4j:bolt://localhost";

    
    
    private Connection conn = null;
    ArrayList statements = new ArrayList(); // list of Statements, PreparedStatements
    PreparedStatement psInsert = null;
    PreparedStatement psUpdate = null;
    Statement s = null;
    Statement t = null;
    ResultSet rs = null;    
    
    rowBean dBbean = new rowBean();   // database buffer is a queue of rowBeans
    List dbbVector = new ArrayList();    
    LoopsDriver mangee = null;
    LoopsDriverTable lMangee = null;    //  totally need an interface here; murderus run90 otherwise
    LoopsDriverTwoPManager tMangee=null;
    LoopsDriverTwoP ttMangee=null;
    FractionIntegerDriver fMangee = null;
    FractionIntegerDriverIterate fiMangee=null;
    BigDecimal zero=new BigDecimal(0);
    LoopList cypherList;
  
    
   public synchronized void goCypher()  {
        try
        {     
            s = conn.createStatement();
            String d="d";
            statements.add(s);
            psInsert = conn.prepareStatement("Create (node:Node {vertex: ? } )");
            statements.add(psInsert);
            psInsert.setString(1, "seven");
            System.out.println(psInsert.execute());
            conn.commit();
           System.out.println("Committed the goCypher");
        }
         catch (SQLException sqle)
        {
            printSQLException(sqle);
        } 
           
    }
 
        public GaussTable1(Semaphore tlSema,List dbVector,LoopsDriverTwoPManager mang){
       dbbVector=dbVector;
       tlSem=tlSema;
       tMangee=mang;
      }
   
   
     public GaussTable1(Semaphore tlSema,List dbVector,LoopsDriverTwoP mang){
       dbbVector=dbVector;
       tlSem=tlSema;
       ttMangee=mang;
      }

   
     public GaussTable1(Semaphore tlSema,List dbVector,LoopsDriverTable mang){
       dbbVector=dbVector;
       tlSem=tlSema;
       lMangee=mang;
      }  

   
   
   public GaussTable1(Semaphore tlSema,List dbVector,LoopsDriver mang){
       dbbVector=dbVector;
       tlSem=tlSema;
       mangee=mang;
      }   
  
    public GaussTable1(Semaphore tlSema,List dbVector,FractionIntegerDriver mang) {
       dbbVector=dbVector;
       tlSem=tlSema;
       fMangee=mang; 
      }   
    
      public GaussTable1(Semaphore tlSema,List dbVector,FractionIntegerDriverIterate mang) {
       dbbVector=dbVector;
       tlSem=tlSema;
       fiMangee=mang; 
      }   
    
private void runFIDi() {     //fraction integer driver iterate
     while ((fiMangee.isAlive()) || (dbbVector.size()>0)) {       
 //            System.out.println("                 runFID while loop " + fiMangee.isAlive() + " "+dbbVector.size());
             try {
                tlSem.acquire();
                System.out.println("                       runFid      ");
                if (dbbVector.size()>0) {
                try {
                   System.out.println("MuNumDen:   "  +((BigDecimal)((muNumDen)dbbVector.get(0)).getMu()).toString()+"  "+ ((BigDecimal)((muNumDen)dbbVector.get(0)).getnumerator()).toString()+"   "+((BigDecimal)((muNumDen)dbbVector.get(0)).getDenominator()).toString()+"   "+((String)((muNumDen)dbbVector.get(0)).getBString()));     
                   goFidCypher(((BigDecimal)((muNumDen)dbbVector.get(0)).getMu()).toString(),((BigDecimal)((muNumDen)dbbVector.get(0)).getnumerator()).toString(),((BigDecimal)((muNumDen)dbbVector.get(0)).getDenominator()).toString(),((String)((muNumDen)dbbVector.get(0)).getBString()),((muNumDen)dbbVector.get(0)).getbStringSize());
                   dbbVector.remove(0);
                } catch (NullPointerException e) {
                System.out.println("dbVector empty"+ e.toString());
                dbbVector.remove(0);
                }
                }
                else {System.out.println("if dbbVector.size()>0 else println   " );}
            } catch (InterruptedException ex) {
                Logger.getLogger(twoTableDBThread.class.getName()).log(Level.SEVERE, null, ex);
            }
 //           System.out.println("twotabledbthread dbVectorSize"+ dbbVector.size());
           }
        
}
    
    
    
    
private void runFID() {
     while ((fMangee.isAlive()) || (dbbVector.size()>0)) {       
             System.out.println("                 runFID while loop " + fMangee.isAlive() + " "+dbbVector.size());
             try {
                tlSem.acquire();
                System.out.println("                       runFid      ");
                if (dbbVector.size()>0) {
                try {
                   System.out.println("MuNumDen:   "  +((BigDecimal)((muNumDen)dbbVector.get(0)).getMu()).toString()+"  "+ ((BigDecimal)((muNumDen)dbbVector.get(0)).getnumerator()).toString()+"   "+((BigDecimal)((muNumDen)dbbVector.get(0)).getDenominator()).toString());     
                   goFidCypher(((BigDecimal)((muNumDen)dbbVector.get(0)).getMu()).toString(),((BigDecimal)((muNumDen)dbbVector.get(0)).getnumerator()).toString(),((BigDecimal)((muNumDen)dbbVector.get(0)).getDenominator()).toString(),((String)((muNumDen)dbbVector.get(0)).getBString()),((muNumDen)dbbVector.get(0)).getbStringSize());
                   //               go(((GaussBean1)dbbVector.get(0)).getpArray(),((GaussBean1)dbbVector.get(0)).getLoopList(),((GaussBean1)dbbVector.get(0)).getWNum(),((GaussBean1)dbbVector.get(0)).getVmResult(),((GaussBean1)dbbVector.get(0)).getresultlistid());
                dbbVector.remove(0);
                } catch (NullPointerException e) {
                System.out.println("                                                                                   dbVector empty"+ e.toString());
                dbbVector.remove(0);
                }
                }
                else {System.out.println("if dbbVector.size()>0 else println   " );}
//                dbbVector.removeElementAt(0);
            } catch (InterruptedException ex) {
                Logger.getLogger(twoTableDBThread.class.getName()).log(Level.SEVERE, null, ex);
            }
 //           System.out.println("twotabledbthread dbVectorSize"+ dbbVector.size());
           }
        
}

private void runLoopsDriver() {
           while ((mangee.isAlive()) || (dbbVector.size()>0)) {       
 //            System.out.println("                                                GaussCorrolation while loop " + mangee.isAlive() + " "+dbbVector.size());
             try {
                tlSem.acquire();
  //              System.out.println("                       gauss6able      ");
                if (dbbVector.size()>0) {
                try {
   //               System.out.println("GaussBean1:   " + ((GaussBean1)dbbVector.get(0)).toString());     
   //             go(((GaussBean1)dbbVector.get(0)).getpArray(),((GaussBean1)dbbVector.get(0)).getLoopList(),((GaussBean1)dbbVector.get(0)).getWNum(),((GaussBean1)dbbVector.get(0)).getVmResult(),((GaussBean1)dbbVector.get(0)).getresultlistid());
                if (((GaussBean1)dbbVector.get(0)).getLoopList().getworkNum()==0) {cypherList=((GaussBean1)dbbVector.get(0)).getLoopList(); }
                goCCypher(((GaussBean1)dbbVector.get(0)).getfigPArray(),((GaussBean1)dbbVector.get(0)).getpArray(),((GaussBean1)dbbVector.get(0)).getLoopList(),((GaussBean1)dbbVector.get(0)).getLoopList().getworkNum(),((GaussBean1)dbbVector.get(0)).getLoopList().getVmResult(),((GaussBean1)dbbVector.get(0)).getresultlistid(),((GaussBean1)dbbVector.get(0)).getfPArray()); 
                dbbVector.remove(0);
                } catch (NullPointerException e) {
                System.out.println("                                                                                   dbVector empty"+ e.toString());
                dbbVector.remove(0);
                }
                }
                else {System.out.println("if dbbVector.size()>0 else println   " );}
//                dbbVector.removeElementAt(0);
            } catch (InterruptedException ex) {
                Logger.getLogger(twoTableDBThread.class.getName()).log(Level.SEVERE, null, ex);
            }
 //           System.out.println("twotabledbthread dbVectorSize"+ dbbVector.size());
           }
}    
    
private void runLoopsDriverr() {
        //   while ((lMangee.isAlive()) || (tMangee.isAlive())   || (dbbVector.size()>0)) 
            while ( (tMangee.isAlive())   || (dbbVector.size()>0))
           {       
             System.out.println("      GaussCorrolation while loop " + tMangee.isAlive() + " "+dbbVector.size());
             try {
                tlSem.acquire();
                //            System.out.println("                       gauss6able      ");
                if (dbbVector.size()>0) {
                try {
                  System.out.println("GaussBean1:   " + ((GaussBean1)dbbVector.get(0)).toString()+ " "+((GaussBean1)dbbVector.get(0)).getfigPArray()+" "+((GaussBean1)dbbVector.get(0)).getpArray()+" "+((GaussBean1)dbbVector.get(0)).getLoopList().getVmResult());     
                //             go(((GaussBean1)dbbVector.get(0)).getpArray(),((GaussBean1)dbbVector.get(0)).getLoopList(),((GaussBean1)dbbVector.get(0)).getWNum(),((GaussBean1)dbbVector.get(0)).getVmResult(),((GaussBean1)dbbVector.get(0)).getresultlistid());
                if (((GaussBean1)dbbVector.get(0)).getLoopList().getworkNum()==0) {cypherList=((GaussBean1)dbbVector.get(0)).getLoopList(); }
                goCCypher(((GaussBean1)dbbVector.get(0)).getfigPArray(),((GaussBean1)dbbVector.get(0)).getpArray(),((GaussBean1)dbbVector.get(0)).getLoopList(),
                        ((GaussBean1)dbbVector.get(0)).getLoopList().getworkNum(),((GaussBean1)dbbVector.get(0)).getLoopList().getVmResult(),
                        ((GaussBean1)dbbVector.get(0)).getresultlistid(),((GaussBean1)dbbVector.get(0)).getfPArray(),((GaussBean1)dbbVector.get(0)).getisTwoPolynomial(),((GaussBean1)dbbVector.get(0)).getevaluateValue()); 
                dbbVector.remove(0);
                } catch (NullPointerException e) {
                System.out.println("                                                                                   dbVector empty"+ e.toString());
                dbbVector.remove(0);
                }
                }
                else {System.out.println("if dbbVector.size()>0 else println   " );}
//                dbbVector.removeElementAt(0);
            } catch (InterruptedException ex) {
                Logger.getLogger(twoTableDBThread.class.getName()).log(Level.SEVERE, null, ex);
            }
          //  System.out.println("twotabledbthread dbVectorSize"+ dbbVector.size());
           }
             System.out.println("GaussTable1.runLoopsDriverr() flowthrough.");
}     






    public void run(){
      startConn();
      System.out.println("                                                                                         It is inside GaussCorrolation? ");
      try {
        Thread.sleep(50000);
      System.out.println("                                     Slept? ");
      } catch (InterruptedException ex) {
        Logger.getLogger(GaussTable1.class.getName()).log(Level.SEVERE, null, ex);
      }
       if (mangee!=null ) {
        runLoopsDriver();          
       } else  if (lMangee!=null || tMangee!= null) {  runLoopsDriverr();}    
       
       else {
         if (fMangee!=null  )  runFID(); else {runFIDi();}
       }
       System.out.println("twotabledbthread ended");
       endConn();      //  maybe endconn is throwing excejptions  
       } 






    
    
    
    
    
//        public void run(){
//         startConn();
//         System.out.println("                                                                                         It is inside GaussCorrolation? ");
//goCypher();
////buildPoly();
//        try {
//            Thread.sleep(20000);
//        } catch (InterruptedException ex) {
//            Logger.getLogger(GaussTable1.class.getName()).log(Level.SEVERE, null, ex);
//       }
//          while ((mangee.isAlive()) || (dbbVector.size()>0)) {       
////             System.out.println("                                                GaussCorrolation while loop " + mangee.isAlive() + " "+dbbVector.size());
//             try {
//                tlSem.acquire();
//
////                System.out.println( ((GaussBean1)dbbVector.get(0)).getLoopList()+" "+((GaussBean1)dbbVector.get(0)).getVmResult()+" "+((GaussBean1)dbbVector.get(0)).getpArray());                                                    // go(double y1,double y2,double y3,BigDecimal trZer,BigDecimal trTr,BigDecimal root1,BigDecimal root2,BigDecimal root3)               
//
////                System.out.println("                       gauss6able      ");
//               if (dbbVector.size()>0) {
// try {
// //                  System.out.println("GaussBean1:   " + ((GaussBean1)dbbVector.get(0)).toString());     
// //                System.out.println("pArray:   " + ((GaussBean1)dbbVector.get(0)).getpArray());               
// //                System.out.println("LoopList:   " + ((GaussBean1)dbbVector.get(0)).getLoopList());
// //                System.out.println("wNum:   " + ((GaussBean1)dbbVector.get(0)).getWNum());
// //                System.out.println("VmResult:   " + ((GaussBean1)dbbVector.get(0)).getVmResult());
// //                System.out.println("resultListId:   " + ((GaussBean1)dbbVector.get(0)).getresultlistid());
// //               ((GaussBean1)dbbVector.get(0)).getLoopList().getworkNum();((GaussBean1)dbbVector.get(0)).getLoopList().getVmResult();
//        if (((GaussBean1)dbbVector.get(0)).getLoopList().getworkNum()==0) {cypherList=((GaussBean1)dbbVector.get(0)).getLoopList(); }
//         goCCypher(((GaussBean1)dbbVector.get(0)).getfigPArray(),((GaussBean1)dbbVector.get(0)).getpArray(),((GaussBean1)dbbVector.get(0)).getLoopList(),((GaussBean1)dbbVector.get(0)).getLoopList().getworkNum(),((GaussBean1)dbbVector.get(0)).getLoopList().getVmResult(),((GaussBean1)dbbVector.get(0)).getresultlistid());
//
////        go(((GaussBean1)dbbVector.get(0)).getfigPArray(),((GaussBean1)dbbVector.get(0)).getpArray(),((GaussBean1)dbbVector.get(0)).getLoopList(),((GaussBean1)dbbVector.get(0)).getLoopList().getworkNum(),((GaussBean1)dbbVector.get(0)).getLoopList().getVmResult(),((GaussBean1)dbbVector.get(0)).getresultlistid());
////                tlToTable(((rowBean)dbbVector.elementAt(0)).getTL(),((rowBean)dbbVector.elementAt(0)).getNN(),((rowBean)dbbVector.elementAt(0)).getFlatFileRowCounter(),((rowBean)dbbVector.elementAt(0)).getNMax());
//                dbbVector.remove(0);
// } catch (NullPointerException e) {
//            System.out.println("                                                                                   dbVector empty"+ e.toString());
//            dbbVector.remove(0);
//            
//        }
// 
// 
// }
//                else {System.out.println("if dbbVector.size()>0 else println   " );}
////                dbbVector.removeElementAt(0);
//            } catch (InterruptedException ex) {
//                Logger.getLogger(twoTableDBThread.class.getName()).log(Level.SEVERE, null, ex);
//            }
// //           System.out.println("twotabledbthread dbVectorSize"+ dbbVector.size());
//           }
//           System.out.println("twotabledbthread ended");
// //          System.out.println("TwoTableDBThread while loop" + mangee.isAlive());
//          //  new method for polynomials 
//        //   buildPoly();
//      endConn();      //  maybe endconn is throwing excejptions  
////    startConn();
////    buildPoly();
////    endConn();
//      //     eDB.go();
//       }   
    
    public synchronized void buildPoly()
    {  //  the querry paramaters are hard coded for now. 
       // the query partamaters are hard codend for now.  see plvManager currently 4,10-22
        BigDecimal n = new BigDecimal(9);
        BigDecimal nMax = new BigDecimal(0);
        BigDecimal increment = new BigDecimal(1);
        
         System.out.println("inside buildpoly");
        try
        { // s.execute("create table results(num numeric(20,0), argument numeric(20,0), scalar numeric(20,0), degree numeric(20,0), rowcounter numeric(20,0), nmax numeric(20,0))"); 
            s = conn.createStatement();
            statements.add(s);
//            System.out.println("NEW Error Code Here!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            psInsert = conn.prepareStatement("MATCH (n:Node) RETURN n");
            statements.add(psInsert);
 

            ResultSet rs = psInsert.executeQuery();
            
            while ( rs.next() ) {
            String num = rs.getString(1);    
      //      Double argument = rs.getDouble(2);
      //      BigDecimal scalar = rs.getBigDecimal(3); 
      //      BigDecimal degree = rs.getBigDecimal(4); 
     //       BigDecimal rowcounter = rs.getBigDecimal(5); 
 
            System.out.println(num);
      //      System.out.println(argument);
     //       System.out.println(scalar);
      //      System.out.println(degree); 
     //       System.out.println(rowcounter);
            
            }
          //  System.out.println("Inserted");
          //  conn.commit();
          //  System.out.println("Committed the transaction");
  //       s.execute("CALL SYSCS_UTIL.SYSCS_EXPORT_TABLE (null,'rootlist','rootlist.txt',null,null,null)");
        }
         catch (SQLException sqle)
        {
            printSQLException(sqle);
        } 

    }
        
        
        
        
        
        
   public void tlToTable(BigDecimal trZero, BigDecimal trTriangle, BigDecimal muDecimal, BigDecimal rootOne, BigDecimal rootTwo,BigDecimal a, BigDecimal b, BigDecimal c, BigDecimal determinat,BigDecimal numerator,BigDecimal denominator){

   
   //      go(trZero,trTriangle,muDecimal,rootOne,rootTwo,a,b,c,determinat,numerator,denominator);

       
       
      } 
        
    
 
     public void startConn()  {
         System.out.println("Connected to  database twotabledb1thread " );
     System.out.println("SimpleApp starting in " + framework + " mode");
     loadDriver();
      try {
           Properties props = new Properties(); // connection properties
            // providing a user name and password is optional in the embedded
            // and derbyclient frameworks
     //       props.put("user",  "aibes");
     //       props.put("password", "Aibeceles1");
     //       String dbName = "muTableDB"; // the name of the database

    //       props.put("user", "root");
    //       props.put("password", "Aibeceles1");
           String dbName = "graph.db";


    //        conn = DriverManager.getConnection(protocol + dbName
     //               + ";", props);
     //       conn = DriverManager.getConnection("jdbc:mysql://localhost/fisdb?user=root&password=Aibeceles1");
  
          //   conn = DriverManager.getConnection(protocol);
             conn = DriverManager.getConnection(protocol, "neo4j", "Aibes");
                     System.out.println(conn.getMetaData().getURL());
     
     
     System.out.println("Connected to  database twotabledb1thread " );
            // We want to control transactions manually. Autocommit is on by
            // default in JDBC.
            conn.setAutoCommit(false);
            
           }

        catch (SQLException sqle)
        {
            printSQLException(sqle);
        } 

   }


  public void endConn()  {


 //           if (framework.equals("embedded"))
            {
                try
                {
                    // the shutdown=true attribute shuts down Derby
           //         DriverManager.getConnection("jdbc:derby:;shutdown=true");
                    conn.close();
                    // To shut down a specific database only, but keep the
                    // engine running (for example for connecting to other
                    // databases), specify a database in the connection URL:
                    //DriverManager.getConnection("jdbc:derby:" + dbName + ";shutdown=true");
                }
                catch (SQLException se)
                {
                    if (( (se.getErrorCode() == 50000)
                            && ("XJ015".equals(se.getSQLState()) ))) {
                        // we got the expected exception
                        System.out.println("Derby shut down normally");
                        // Nte that for single database shutdown, the expected
                        // SQL state is "08006", and the error code is 45000.
                    } else {
                        // if the error code or SQLState is different, we have
                        // an unexpected exception (shutdown failed)
                        System.err.println("Derby did not shut down normally");
                        printSQLException(se);
                    }
                }
            
//  need to close statements
            int i = 0;
            while (!statements.isEmpty()) {
                // PreparedStatement extend Statement
                Statement st = (Statement)statements.remove(i);
                try {
                    if (st != null) {
                        st.close();
                        st = null;
                    }
                } catch (SQLException sqle) {
                    printSQLException(sqle);
                }

            }
//  neede to close connection
            //Connection
            try {
                if (conn != null) {
                    conn.close();
                    conn = null;
                }
            } catch (SQLException sqle) {
                printSQLException(sqle);
            }
//  there is no reading so result set is irrelevant.
          // release all open resources to avoid unnecessary memory usage
            // ResultSet
            try {
                if (rs != null) {
                    rs.close();
                    rs = null;
                }
            } catch (SQLException sqle) {
                printSQLException(sqle);
            }
        }
}

//  Sub methods implementing cypher querries:
// 
  

private void mergeVmResultt(String vmResult) {
 
    
//        System.out.println("GaussTablle1.mergeVmResult fParray: " + fPArray.toString());
        try {
            s = conn.createStatement();
            statements.add(s);
            psInsert = conn.prepareStatement("MERGE (d:Dnode {vmResult:?}) ");
            statements.add(psInsert);
            psInsert.setString(1, vmResult);
 //           psInsert.setString(2, pArray);
            psInsert.executeUpdate();
            conn.commit();
        } catch (SQLException sqle) { printSQLException(sqle); }
//        try {rs.close(); } catch (SQLException ex) {
//            Logger.getLogger(GaussTable1.class.getName()).log(Level.SEVERE, null, ex);
//        }
}
  
  private void mergeVmResult(String vmResult,PolynomialArray fPArray) {
 
    
        System.out.println("GaussTablle1.mergeVmResult fParray: " + fPArray.toString());
        try {
            s = conn.createStatement();
            statements.add(s);
            psInsert = conn.prepareStatement("MERGE (d:Dnode {vmResult:?,constant:?,linear:?,square:?}) ");
            statements.add(psInsert);
            psInsert.setString(1, vmResult);
            psInsert.setInt(2, (int)fPArray.get(0));
            psInsert.setInt(3, (int)fPArray.get(1));
            psInsert.setInt(4, (int)fPArray.get(2));
 //           psInsert.setString(2, pArray);
            psInsert.executeUpdate();
            conn.commit();
        } catch (SQLException sqle) { printSQLException(sqle); }
//        try {rs.close(); } catch (SQLException ex) {
//            Logger.getLogger(GaussTable1.class.getName()).log(Level.SEVERE, null, ex);
//        }
}

private void createWnumRcounter(int wNum,int rCounter,String pArray) {
      try {
            s = conn.createStatement();
            statements.add(s);
            psInsert = conn.prepareStatement("Merge (d:CreatedBy {resultId:?, wNum:?,pArray:?} )");
            statements.add(psInsert);
            psInsert.setInt(1, rCounter);
            psInsert.setInt(2, wNum);
            psInsert.setString(3,pArray);
            psInsert.executeUpdate();
            conn.commit();   
      }  catch (SQLException ex) {
            Logger.getLogger(GaussTable1.class.getName()).log(Level.SEVERE, null, ex);
      }
}

private void createKnownByRelation(String vmResult,int wNum, int rCounter)   {
       try {   
            s = conn.createStatement();
            statements.add(s);
            psInsert = conn.prepareStatement(" MATCH (d:Dnode), (k:CreatedBy) WHERE d.vmResult=? AND k.resultId=? AND k.wNum=? WITH d,k MERGE  (d)-[ee:CreatedBye]->(k)");
            statements.add(psInsert);
            psInsert.setString(1, vmResult);
            psInsert.setInt(2, rCounter);
            psInsert.setInt(3, wNum);
            psInsert.executeUpdate();
            conn.commit();    
        }  catch (SQLException ex) {
            Logger.getLogger(GaussTable1.class.getName()).log(Level.SEVERE, null, ex);
        }
}

private void createEvaluates(LoopList loopList,String vmResult) {
    BigDecimal bD= new BigDecimal(0);
    Double bDD;
    System.out.println("     !!!! createEvaluates      !!!!!");
    try {
            int lSize= loopList.size();
            bD=(BigDecimal)loopList.get(0);  //  just need a bigdecimal definedas zero
            bDD=bD.doubleValue();            //  maybe these two lines are unnecessary

            for (Integer x=0;x<lSize;x++){
            System.out.print(" "+((BigDecimal)cypherList.get(x)).toString());
            if (((BigDecimal)cypherList.get(x)).compareTo(zero)==0) { 
            String X=x.toString();
    //        X=X.substring(0, 1);                             // could be a silly mistake...
            System.out.print ("    X:" +X+ "     x.toString()  "+ x.toString()+"     ");
            System.out.print(bDD);
            s = conn.createStatement();
            statements.add(s);
            psInsert = conn.prepareStatement(" MATCH (e:Evaluate), (d:Dnode) WHERE e.Value = ? AND d.vmResult=? WITH d,e MERGE  (d)-[ee:Envalues]->(e)");
            statements.add(psInsert);
            psInsert.setString(1, X);
            psInsert.setString(2, vmResult);
            psInsert.executeUpdate();
            conn.commit();
            }
          }
        } catch (SQLException sqle)
        {
            printSQLException(sqle);
        } 
    System.out.println();
} 

private void createZMap(String vmResult,int rCounter,int wNum)   {
        try {
            s = conn.createStatement();
            statements.add(s);
 System.out.println("gausstable1.createZmap() wNm,vmResult,rCounter "+" "+wNum+" "+vmResult+" "+rCounter); 
//         psInsert = conn.prepareStatement(" MATCH (d:Dnode), (c:CreatedBy) WHERE d.vmResult=? AND c.resultID=?  AND c.wNum=?  WITH d,e CREATE  (d)-[ee:zMap]->(e)");
            psInsert = conn.prepareStatement("match  (d:Dnode)-[:CreatedBye]->(c:CreatedBy {resultId:? , wNum:?}) , (dd:Dnode)-[:CreatedBye]->(cc:CreatedBy {resultId:? , wNum:?}) MERGE (d)-[:zMap]->(dd) ");
            statements.add(psInsert);
            psInsert.setInt(1, rCounter);
            psInsert.setInt(2, wNum);
            psInsert.setInt(3, rCounter);
            psInsert.setInt(4, wNum-1);
            psInsert.executeUpdate();
            conn.commit();
        } catch (SQLException ex) {
            Logger.getLogger(GaussTable1.class.getName()).log(Level.SEVERE, null, ex);
        }
   
}

/*
*  Only for LoopsDriver signature.
*/


public synchronized void goCCypher(String figPArray,String pArray,LoopList loopList,int wNum,String vmResult,int rCounter, PolynomialArray fPArray)  {
    BigDecimal bD= new BigDecimal(0);
    Double bDD;
    int index;
    System.out.println("goCCypher() figPArray,pArray,wNm,vmResult,rCounter "+figPArray+" "+pArray+" "+wNum+" "+vmResult+" "+rCounter);
    System.out.println("goCCypher() "+loopList.toString());


            if (wNum==0) {
                mergeVmResult(vmResult,fPArray);
            //    if (rCounter!=-99) {
                   createWnumRcounter(wNum,rCounter,pArray);
                   createKnownByRelation(vmResult,wNum,rCounter);
           //     }   
                createEvaluates(loopList,vmResult);
                
            }
            if (wNum>0)
            {
                mergeVmResultt(vmResult);
            //    if (rCounter!=-99) {
                createWnumRcounter(wNum,rCounter,pArray);
                createKnownByRelation(vmResult,wNum,rCounter);
            //    }
                createZMap(vmResult,rCounter,wNum);
            }
    }

/*
*  The appropriate signature for LoopsDriverTwoPManager()
*/


public synchronized void goCCypher(String figPArray,String pArray,LoopList loopList,int wNum,String vmResult,int rCounter, PolynomialArray fPArray,boolean isTwoPolynomial,String evaluateValue)  {
    BigDecimal bD= new BigDecimal(0);
    Double bDD;
    int index;
    System.out.println("goCCypher() figPArray,pArray,wNm,vmResult,rCounter "+figPArray+" "+pArray+" "+wNum+" "+vmResult+" "+rCounter);
    System.out.println("goCCypher() "+loopList.toString());


            if (wNum==0) {
                mergeVmResult(vmResult,fPArray);
            //    if (rCounter!=-99) {
             if (isTwoPolynomial) {createTwoPRelation(vmResult,evaluateValue);}
            createWnumRcounter(wNum,rCounter,pArray);
                   createKnownByRelation(vmResult,wNum,rCounter);
           //     }   
                createEvaluates(loopList,vmResult);
                
            }
            if (wNum>0)
            {
                mergeVmResultt(vmResult);
            //    if (rCounter!=-99) {
                createWnumRcounter(wNum,rCounter,pArray);
                createKnownByRelation(vmResult,wNum,rCounter);
            //    }
                createZMap(vmResult,rCounter,wNum);
            }
    }

private synchronized void createTwoPRelation(String vmResult,String evaluateValue) {

       System.out.println("GaussTable1.createTwoPRelation vmResult,evaluateValue"+vmResult+"    "+evaluateValue);
       try {   
            s = conn.createStatement();
            statements.add(s);
            psInsert = conn.prepareStatement(" MATCH (d:Dnode), (e:Evaluate) WHERE d.vmResult=? AND e.Value=? WITH d,e MERGE  (d)-[ee:TwoPolynomial]->(e)");
            statements.add(psInsert);
            psInsert.setString(1, vmResult);
            psInsert.setString(2, evaluateValue);
            psInsert.executeUpdate();
            conn.commit();    
        }  catch (SQLException ex) {
            Logger.getLogger(GaussTable1.class.getName()).log(Level.SEVERE, null, ex);
        }


    
}


private synchronized void mergeEvaluate(String mU, String numerator, String denominator,String nBinary,int nBinarySize){
 
        try {
            s = conn.createStatement();
            statements.add(s);
            psInsert = conn.prepareStatement("MERGE (e:Evaluate {Value:?}) SET e.n=?,e.d=?,e.nBinary=?,e.Size=?");
  //          psInsert = conn.prepareStatement("create (e:Evaluate {Value:?,n:?,d:?,nBinary:?})");
            statements.add(psInsert);
            psInsert.setString(1, mU);
            psInsert.setString(2, numerator);
            psInsert.setString(3, denominator);
            psInsert.setString(4, nBinary);
            psInsert.setInt(5, nBinarySize);
            psInsert.executeUpdate();
            conn.commit();   
      }  catch (SQLException ex) {
            Logger.getLogger(GaussTable1.class.getName()).log(Level.SEVERE, null, ex);
      } 
}   



public synchronized void goFidCypher(String mU, String numerator, String denominator,String nBinary,int nBinarySize)  {

   mergeEvaluate( mU, numerator,denominator,nBinary,nBinarySize);
   
}




public synchronized void go(String figPArray,String pArray,LoopList loopList,int wNum,String vmResult,int rCounter)  {
    BigDecimal bD= new BigDecimal(0);
    Double bDD;
    
    int index;
    System.out.println("gausstable1.go() figPArray,pArray,wNm,vmResult,rCounter "+figPArray+" "+pArray+" "+wNum+" "+vmResult+" "+rCounter);
        try
        {     
            s = conn.createStatement();
            statements.add(s);
            System.out.println("gaussiterationtable!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"+ bD.toString());
            System.out.println(pArray.toString());
            psInsert = conn.prepareStatement("CREATE (d:Dnode {Polynomial:? , vmResult:? , resultID:?, wNum:?} )");
            statements.add(psInsert);
            System.out.println("gaussiterationtable!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"+ bD.toString());
            psInsert.setString(1, figPArray);
            psInsert.setString(2, vmResult);
            psInsert.setInt(3, rCounter);
            psInsert.setInt(4, wNum);
            psInsert.executeUpdate();
            conn.commit();
            if (wNum==0) {
            int lSize= loopList.size();
            System.out.println("gaussiterationtable    wNum=1!!!!!   lSize: "+ lSize + " " );
            bD=(BigDecimal)loopList.get(0);
            bDD=bD.doubleValue(); 
            for (int x=0;x<lSize;x++){
            System.out.println("gaussiterationtable.go() loop cypherList.get(x): "+ ((BigDecimal)cypherList.get(x)) );    
            if (((BigDecimal)cypherList.get(x)).compareTo(zero)==0) {    
            s = conn.createStatement();
            statements.add(s);
            System.out.println("gaussiterationtable!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"+ bD.toString());
            System.out.println(pArray.toString());
            psInsert = conn.prepareStatement(" MATCH (e:Evaluate), (d:Dnode) WHERE e.Value = ? AND d.Polynomial=? AND d.vmResult=? AND d.resultID=? WITH d,e MERGE  (d)-[ee:Envalues]->(e)");
                                     // psInsert = conn.prepareStatement("CREATE (d:Dnode {Polynomial:? vmResult:? , resultID:?} ) RETURN d");
            statements.add(psInsert);
            System.out.println("gaussiterationtable!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"+ bD.toString());
            psInsert.setInt(1, x);
            psInsert.setString(2, figPArray);
            psInsert.setString(3, vmResult);
            psInsert.setInt(4, rCounter);
            psInsert.executeUpdate();
            conn.commit();
            }
            }
            }
            if (wNum>0)
            {
            s = conn.createStatement();
            statements.add(s);
            System.out.println("gaussiterationtable!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"+ bD.toString());
            System.out.println(pArray.toString());
            psInsert = conn.prepareStatement(" MATCH (e:Dnode), (d:Dnode) WHERE e.Polynomial=? AND e.wNum=? AND e.resultID=?  AND d.Polynomial=? AND d.wNum=? AND d.resultID=? WITH d,e MERGE  (d)-[ee:zMap]->(e)");
       // psInsert = conn.prepareStatement("CREATE (d:Dnode {Polynomial:? vmResult:? , resultID:?} ) RETURN d");
            statements.add(psInsert);
            System.out.println("gaussiterationtable!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"+ bD.toString());
            psInsert.setString(1, figPArray);
            psInsert.setInt(2, wNum);
            psInsert.setInt(3, rCounter);
            psInsert.setString(4, figPArray);
            psInsert.setInt(5, wNum-1);
            psInsert.setInt(6, rCounter);
            psInsert.executeUpdate();
            conn.commit();
            }
        }
         catch (SQLException sqle)
        {
            printSQLException(sqle);
        } 
//    }
    }

    public synchronized void goResults(BigDecimal n, BigDecimal argument, BigDecimal scalar, BigDecimal degree, BigDecimal flatFileRowCounter, BigDecimal nMax)
    {
    BigDecimal counter= new BigDecimal(1);
    BigDecimal increment = new BigDecimal(1);
    BigDecimal zero = new BigDecimal(0);
    BigDecimal one = new BigDecimal(1);
    BigDecimal two = new BigDecimal(2);
    BigDecimal result = new BigDecimal(0);
    BigDecimal square = new BigDecimal(0);
    int i = nMax.intValue();    
    
    for (int j=0; j<i; j++) {
        try
        {     // s.execute("create table results(num numeric(20,0), argument numeric(20,0), scalar numeric(20,0), degree numeric(20,0), rowcounter numeric(20,0), nmax numeric(20,0))"); 
            if (degree.compareTo(zero)==0) { result=scalar; }
            if (degree.compareTo(one)==0)  { result=scalar.multiply(counter); }
            if (degree.compareTo(two)==0) 
            {
                square=zero;
                square=counter.pow(2);
                result=scalar.multiply(square);
            } 
            s = conn.createStatement();
            statements.add(s);
            System.out.println("NEW Error Code Here!!!!!!and here");
            psInsert = conn.prepareStatement("insert into results values(?, ?, ?, ?, ?, ?, ?, ?)");
            statements.add(psInsert);
            psInsert.setBigDecimal(1, n);
            psInsert.setBigDecimal(2, argument);
            psInsert.setBigDecimal(3, scalar);
            psInsert.setBigDecimal(4, degree);
            psInsert.setBigDecimal(5, flatFileRowCounter);
            psInsert.setBigDecimal(6, nMax);
            psInsert.setBigDecimal(7, counter);
            psInsert.setBigDecimal(8, result); 
            
            psInsert.executeUpdate();
            System.out.println("Inserted");
            conn.commit();
            System.out.println("Committed the transaction");
        }
         catch (SQLException sqle)
        {
            printSQLException(sqle);
        } 
      }    
    }
    
    
    
    
    
    
    
    
    
    
    
    private void loadDriver() {
        try {
    
            Class.forName("org.neo4j.jdbc.Driver").newInstance();
          //  Class.forName(driver).newInstance();
            System.out.println("Loaded the appropriate driver");
        } catch (ClassNotFoundException cnfe) {
            System.err.println("\nUnable to load the JDBC driver " + driver);
            System.err.println("Please check your CLASSPATH.");
            cnfe.printStackTrace(System.err);
        } catch (InstantiationException ie) {
            System.err.println(
                        "\nUnable to instantiate the JDBC driver " + driver);
            ie.printStackTrace(System.err);
        } catch (IllegalAccessException iae) {
            System.err.println(
                        "\nNot allowed to access the JDBC driver " + driver);
            iae.printStackTrace(System.err);
        }
    }

    private void reportFailure(String message) {
        System.err.println("\nData verification failed:");
        System.err.println('\t' + message);
    }

    public static void printSQLException(SQLException e)
    {
        // Unwraps the entire exception chain to unveil the real cause of the
        // Exception.
        while (e != null)
        {
            System.err.println("\n----- SQLException -----");
            System.err.println("  SQL State:  " + e.getSQLState());
            System.err.println("  Error Code: " + e.getErrorCode());
            System.err.println("  Message:    " + e.getMessage());
            // for stack traces, refer to derby.log or uncomment this:
            e.printStackTrace(System.err);
            e = e.getNextException();
        }
    }


    private void parseArguments(String[] args)
    {
        if (args.length > 0) {
            if (args[0].equalsIgnoreCase("derbyclient"))
            {
                framework = "derbyclient";
                driver = "org.apache.derby.jdbc.ClientDriver";
                protocol = "jdbc:derby://localhost:1527/";
            }
        }
    }   
    
    public String getSampleProperty() {
        return sampleProperty;
    }
    
    public void setSampleProperty(String value) {
        String oldValue = sampleProperty;
        sampleProperty = value;
        propertySupport.firePropertyChange(PROP_SAMPLE_PROPERTY, oldValue, sampleProperty);
    }
    
    public void addPropertyChangeListener(PropertyChangeListener listener) {
        propertySupport.addPropertyChangeListener(listener);
    }
    
    public void removePropertyChangeListener(PropertyChangeListener listener) {
        propertySupport.removePropertyChangeListener(listener);
    }







}




