/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MainClass;

import LoopsLogic.LoopsLogicLoopSemaphore;
import LoopsSemaphorePattern.LoopsSemaphoreInterface;
import PArrayReset.PArrayResetFlag;
import PArrayReset.PolynomialArray;
import PArrayReset.ResultListID;
import fractionintegerset.EndProduct;
import fractionintegerset.ResultListBean;
import static java.lang.Boolean.TRUE;
import java.lang.management.ManagementFactory;
import java.lang.management.ThreadMXBean;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;
import mugauss.GaussMain;
import twopolynomial.plvManager;
import twopolynomial.rowBean;
import twopolynomial.vertex;

/**
 *
 * @author Aibes
 */
public class LoopsDriverTwoPManager extends Thread    {
 int dimension=2;    
int integerRange=20;     //  The loopListener needs to know this value for its runnable.   
int setProductRange=15;
//int setProductRange=20;
int vDisplacement=0;
int workerCounter=0;
private  ResultListID resultListId=new ResultListID(100);
//ResultListID resultListId = new ResultListID();

ExecutorService executorService1 = Executors.newFixedThreadPool(50);    
CompletionService<String> service = new ExecutorCompletionService<>(executorService1);    
Semaphore muSem = new Semaphore(1);
List muList = new ArrayList();            
GaussMain gMain = new GaussMain();
List semaphoreListF = new ArrayList();
List semaphoreListB = new ArrayList();


PolynomialArray pArray = null;    // 
PolynomialArray figPArray = null;  // the second field variable in figPArray is the leading P scalar.
PolynomialArray cashedFigPArray =  null;


//  PolynomialArray pArray = new PolynomialArray(dimension);    // 
//  PolynomialArray figPArray = new PolynomialArray(dimension,2);  // the second field variable in figPArray is the leading P scalar.
//   PolynomialArray cashedFigPArray = new PolynomialArray(dimension,1);

ResultListBean rListB =new ResultListBean();
ResultListBean allrListB =new ResultListBean();
List ancestorlist = new ArrayList();
List deltaList=new ArrayList();
ResultListBean cashedrListB =new ResultListBean();
//ResultListBean cashedrListB;
PolynomialArray cashedPArray = new PolynomialArray(dimension);
//PolynomialArray cashedPArray new PolynomialArray(dimension);     

//PolynomialArray cashedFigPArray;
EndProduct endProduct=new EndProduct(); 
//LoopsLogicLoopSemaphore loopsLogic;  //any class that extends AbstractLoopSemaphore
//LoopsSemaphoreInterface loopsLogic= new LoopsLogicLoopSemaphore(); 
//LoopsSemaphoreInterface loopsLogic;
LoopsLogicLoopSemaphore loopsLogic;
PArrayResetFlag pArrayResetFlag = new PArrayResetFlag();
final ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
//int numeratorLow=0;
//int numeratorHigh=5;
plvManager mage;
    private BigDecimal NN=null;
    private BigDecimal flatFileRowCounterr=null;
    private BigDecimal nMaxx=null;   //  setters, because of setfields, sould be private???
    private BigDecimal tSeqDB=null;
    private BigDecimal bTermDB=null;
    private BigDecimal targetEvaluateDB=null;
    private vertex vertexDB=null;
    private Semaphore tl1Semaphore;
    private List dbVector11= new ArrayList();

Semaphore muSem1 = new Semaphore(1);
List muList1 = new ArrayList();





public LoopsDriverTwoPManager(List muList,Semaphore muSem,LoopsLogicLoopSemaphore loopsLogic,Semaphore muSem1,List muList1,plvManager mage,Semaphore tl1Semaphore,List dbVector11) {
   this.muList=muList;
   this.muSem=muSem;
   this.muList1=muList;
   this.muSem1=muSem;
   this.loopsLogic=loopsLogic;
   this.mage=mage;
   this.tl1Semaphore=tl1Semaphore;
   this.dbVector11=dbVector11;
}    
    
@Override
public void run() {

   int workerCount=0;
   int switchValue;
   int constant=0,linear=0,square=0;
    int dbVector11Counter=0;
 //   if ((mage.isAlive()) || (dbVector11.size()>0))
   try {
        Thread.sleep(7000);
    } catch (InterruptedException ex) {
        Logger.getLogger(LoopsDriverTable.class.getName()).log(Level.SEVERE, null, ex);
    }
  while ((mage.isAlive()) || (dbVector11.size()>0)) 
    {       
    //             PolynomialArray figTArray = new PolynomialArray(3);
             dbVector11Counter++;
        //            System.out.println("                                                GaussCorrolation while loop " + mangee.isAlive() + " "+dbbVector.size());
             try {
                this.tl1Semaphore.acquire();
  //              System.out.println("                       gauss6able      ");
                if (dbVector11.size()>0) {
                try {
                  System.out.println("LoopsDriverTwoP rowBean:   " + ((rowBean)dbVector11.get(0)).getNMax());     
                  this.NN=((rowBean)dbVector11.get(0)).getNN();
                  System.out.println("this.NN"+" "+this.NN.toString());
                  this.nMaxx=((rowBean)dbVector11.get(0)).getNMax();
                  System.out.println("this.nMaxx"+" "+this.nMaxx.toString());
                  this.vertexDB=((rowBean)dbVector11.get(0)).getvertex();
                  System.out.println("this.vertexDB"+" "+this.vertexDB.toString()+" "+this.vertexDB.getScalar()+" "+this.vertexDB.getDegree());
                  dbVector11.remove(0);
                } catch (NullPointerException e) {
                System.out.println("                                                                                   dbbVector11 empty"+ e.toString());
                dbVector11.remove(0);
                }
                }
                else {System.out.println("if dbbVector.size()>0 else println   " );}
//                dbbVector.removeElementAt(0);
            } catch (InterruptedException ex) {
                Logger.getLogger(LoopsDriverTwoP.class.getName()).log(Level.SEVERE, null, ex);
            }
             switchValue=vertexDB.getDegree().intValue();
             switch ( switchValue){
                 case 0:
                     constant=(((vertexDB.getScalar().intValue())/2)+NN.intValue())-vDisplacement;
                     break;
                 case 1:
                     linear=vertexDB.getScalar().intValue()/2;
                     break;
                 case 2:
                     square=vertexDB.getScalar().intValue()/2;
                     break;
             }
             System.out.println("LoopsDriverTwoPManager.dbVector11Counter: "+dbVector11Counter); 
             if (dbVector11Counter==12 || (dbVector11Counter==15) || (dbVector11Counter==18)) 
                {
              //  if (dbVector11Counter==6) 
                {
                    
                System.out.println("dbVector11Counter==6");    
                figPArray = new PolynomialArray(constant,linear,square);
                cashedFigPArray = new PolynomialArray(constant,linear,square);
                //               figPArray = new PolynomialArray(96,-2,2);
                 pArray = new PolynomialArray(dimension,TRUE);    // 
            
                              System.out.println("LoopsDriverTwoPManager.run.figPArray: "+figPArray.toString());
                              System.out.println("LoopsDriverTwoPManager.run.cashedFigPArray: "+cashedFigPArray.toString());
                              System.out.println("LoopsDriverTwoPManager.run.pArray: "+pArray.toString());
               Callable worker = (Callable) new LoopsDriverTwoP(muList,muSem,loopsLogic,muSem1,muList1,mage,tl1Semaphore,dbVector11,(PolynomialArray)figPArray.clone(),(PolynomialArray)cashedFigPArray.clone(),(PolynomialArray)pArray.clone(),nMaxx.intValue(),resultListId);
               service.submit(worker); workerCount++;

                } //if (dbVector11Counter==6)
               //if (dbVector11Counter==6) { zadTwoP(); }
             }
    }         

   try {
       executorService1.shutdown();
   
       while (workerCount>0)   {
//       while (!executorService1.isTerminated()) {    
       final Future<String> future = service.take();
       System.out.println("service.take "+future.get());
       System.out.println("isTerminated() ThreadMXBean:    "+Arrays.toString(bean.getAllThreadIds()));
       System.out.println();System.out.println();System.out.println();
       workerCount--;
//       System.out.println("AllRlistB  " + allrListB.toString()  );
        }   
   } catch (ExecutionException | InterruptedException ex) {
   ex.printStackTrace();
   } 





}    
    
    
    
    
}
