/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LoopLists;

import LoopsLogic.ModuloList;
import PArrayReset.PolynomialArray;
import fractionintegerset.*;
import java.beans.PropertyChangeSupport;
import java.beans.PropertyChangeListener; 
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Psi_i represented as pArray is associated with a collection of LoopList, each a list of DeltaDelta_j values. 
 * LoopList is also a wrapper for state fields.   
 * 
 * 
 * method setGBList otherwise overides ArrayList set method.
 * @author HP_Administrator
 */
public class LoopList extends ArrayList implements Serializable {
    
    //public static final String PROP_SAMPLE_PROPERTY = "sampleProperty";
    
    //private String sampleProperty;
    private Long threadId;
    private PropertyChangeSupport propertySupport;
    private ResultListBean rListB;
    private int dimension;
    private int integerRange;
    private int workNum;
    private List deltaList;
 //   private List deltaTerm = new ArrayList();
 //   private List ancestorTerm = new ArrayList();
    private List ancestorlist = new ArrayList();
    private List cashedrListB = new ArrayList();         // maybe just declared and not also constructed because is assigned in constructor
    private List thisList=new ArrayList();
    private ModuloList moduloList;
    private MatrixA aMatrix;
    private String vmResult;
    
    
    public LoopList() {
        propertySupport = new PropertyChangeSupport(this);
        
    }
     
    /* The copy constructor
    
    */
        
    public LoopList (LoopList origonalLoopList, ResultListBean cashedRListB)  {
  //   rListB=cashedRListB;                                                            // wrong 
     this.dimension=origonalLoopList.dimension;
     this.integerRange=origonalLoopList.integerRange;
     this.workNum=origonalLoopList.workNum;
     for (int i=0;i<thisList.size();i++) {
         ((List)this.thisList).add(((List)origonalLoopList.thisList).get(i));
     }   
     BigDecimal listVariable;
     for (int i=0;i<origonalLoopList.size();i++) {
         listVariable=(BigDecimal)origonalLoopList.get(i);
         this.add(listVariable);
     }
 //    System.out.println("LoopList  copy constructor  old LoopList "+ origonalLoopList.toString());
  //   System.out.println("LoopList  copy constructor  new LoopList "+ this.toString());
     this.aMatrix=new MatrixA(origonalLoopList.getAMatrix());
    }
    
   
    
       public LoopList(int mDimension, ResultListBean rListB,int dimension,int integerRange,int workNum, MatrixA aMatrix, PolynomialArray pArray,ModuloList moduloList,Boolean b) {
        propertySupport = new PropertyChangeSupport(this);
        this.rListB=rListB;
        this.dimension=dimension;
        this.integerRange=integerRange;
        this.workNum=workNum;

    //    System.out.println("LoopsDriverTable.LoopListconstructor pre new MartixA, mDimension "+ mDimension);
        this.aMatrix= new MatrixA(mDimension,mDimension+1,aMatrix);
    //    System.out.println("LoopListconstructor post new MartixA");
        this.moduloList=moduloList;
        initializePArrayLoopList(pArray,b);
     } 
    
    
    
    public LoopList(int mDimension, ResultListBean rListB,int dimension,int integerRange,int workNum, MatrixA aMatrix, PolynomialArray pArray,ModuloList moduloList) {
        propertySupport = new PropertyChangeSupport(this);
        this.rListB=rListB;
        this.dimension=dimension;
        this.integerRange=integerRange;
        this.workNum=workNum;

//        System.out.println("LoopListconstructor pre new MartixA, mDimension "+ mDimension);
        this.aMatrix= new MatrixA(mDimension,mDimension+1,aMatrix);
//        System.out.println("LoopListconstructor post new MartixA");
        this.moduloList=moduloList;
        initializePArrayLoopList(pArray);
     } 





    public LoopList(int mDimension, ResultListBean rListB,int dimension,int integerRange,int workNum, MatrixA aMatrix,List transferList) {
        propertySupport = new PropertyChangeSupport(this);
        this.rListB=rListB;
        this.dimension=dimension;
        this.integerRange=integerRange;
        this.workNum=workNum;
   //     this.deltaList=deltaList;
   //     this.ancestorlist=ancestorlist;
   //     this.cashedrListB=cashedrListB;
  //     System.out.println("LoopListconstructor pre new MartixA, mDimension "+ mDimension);
   this.aMatrix= new MatrixA(mDimension,mDimension+1,aMatrix);
  //      System.out.println("LoopListconstructor post new MartixA");
      //  LoadTransferList(transferList);
      //  firstdeltaTermInit();
       initializeTransferLoopList(transferList);
     }  
    
    public LoopList(int mDimension, ResultListBean rListB,int dimension,int integerRange,int workNum,List deltaList,List ancestorlist,List cashedrListB, MatrixA aMatrix) {
        propertySupport = new PropertyChangeSupport(this);
        this.rListB=rListB;
        this.dimension=dimension;
        this.integerRange=integerRange;
        this.workNum=workNum;
        this.deltaList=deltaList;
        this.ancestorlist=ancestorlist;
        this.cashedrListB=cashedrListB;
 //       System.out.println("LoopListconstructor pre new MartixA, mDimension "+ mDimension);
        this.aMatrix= new MatrixA(mDimension,mDimension+1,aMatrix);
        initializeList();
      //  firstdeltaTermInit();
    }   
      
    private void LoadTransferList(List transferList){
 //       System.out.println("LoopListLoadTransferList start");
        for (int n=0;n<transferList.size();n++) {
          this.add(transferList.get(n));
          thisList.add(transferList.get(n));
      } 
 //       System.out.println("LoopListLoadTransferList fall through" + this.toString());
 
    }
    
 //   LoopList gbList1 = new LoopList(rListB,dimension,integerRange,numerator,deltaList,ancestorlist,cashedrListB,xPowers);
 
//  evaluate pArray over integerRange are Looplists_i  
     
 private void loadPArray(PolynomialArray pArray)  {
     
    BigDecimal listValue=new BigDecimal(1);      //result
    BigDecimal listValueResult=new BigDecimal(0);   
    BigDecimal zero=new BigDecimal(0);
    BigDecimal bigDecimalRange=new BigDecimal(0); // synchronized with x
    BigDecimal bigDecimalDimension=new BigDecimal(dimension);
    BigDecimal one=new BigDecimal(1);
    BigDecimal listPower1=new BigDecimal(1);
    BigDecimal result=new BigDecimal(0);
//    BigDecimal currentPcoeff=new BigDecimal(0);
//    System.out.println("looplist.loadPArray.dimension: " + dimension); 
    for(int x=0;  x<(integerRange); x++){
      listValueResult=zero;
      BigDecimal currentK=new BigDecimal(x);                                                     // k as in Psi_i, triag,triag_j, k   
 //     System.out.println("LoopList.loadPArray.x: " + x); 
      for (int y=0;  y<(dimension+1); y++){          // currentPcoeff is scalar 
          BigDecimal currentPcoeff=new BigDecimal((int)pArray.get(y));
 //         System.out.println("currentPcoeff: " + currentPcoeff.toString() +  "  y: "+y+"    currentK: "+ currentK.toString()); 
 //         System.out.println("currentK.pow(y+1): " + currentK.pow(y+1).toString()); 
          listValue=currentK.pow(y);                                   // listValue=currentK.pow(y+1);
 //         System.out.println("listValue: " + listValue.toString() +  "  "); 
          listValueResult=listValueResult.add(listValue.multiply(currentPcoeff));
      }
//      System.out.println("LoopList.loadPArray.listValueResult: "+listValueResult.toString());
      this.add(listValueResult);thisList.add(listValueResult);
     //  bigDecimalRange=bigDecimalRange.add(one);
         listValue=zero;
    }   
  //    rListB.add(this);
   }
  
 private void loadPArray(PolynomialArray pArray,boolean b)  {
     
    BigDecimal listValue=new BigDecimal(1);      //result
    BigDecimal listValueResult=new BigDecimal(0);   
    BigDecimal zero=new BigDecimal(0);
    BigDecimal bigDecimalRange=new BigDecimal(0); // synchronized with x
    BigDecimal bigDecimalDimension=new BigDecimal(dimension);
    BigDecimal one=new BigDecimal(1);
    BigDecimal listPower1=new BigDecimal(1);
    BigDecimal result=new BigDecimal(0);
//    BigDecimal currentPcoeff=new BigDecimal(0);
//    System.out.println("looplist.loadPArray.dimension: " + dimension); 
    for(int x=0;  x<(integerRange); x++){
      listValueResult=zero;
      BigDecimal currentK=new BigDecimal(x);                                                     // k as in Psi_i, triag,triag_j, k   
  //    System.out.println("loadPArray: " + x); 
      BigDecimal currentPcoeff1=new BigDecimal((int)pArray.get(0));
      listValueResult=listValueResult.add(currentPcoeff1);
      for (int y=0;  y<(dimension+1); y++){          // currentPcoeff is scalar 
          BigDecimal currentPcoeff=new BigDecimal((int)pArray.get(y+1));
//          System.out.println("currentPcoeff: " + currentPcoeff.toString() +  "  "); 
          listValue=currentK.pow(y+1);
//          System.out.println("listValue: " + listValue.toString() +  "  ");
          listValueResult=listValueResult.add(listValue.multiply(currentPcoeff));
//          System.out.println("listValueResult: " + listValueResult.toString() +  "  ");
      }
//      System.out.println();
      this.add(listValueResult);thisList.add(listValueResult);
     //  bigDecimalRange=bigDecimalRange.add(one);
         listValue=zero;
    }   
  //    rListB.add(this);
   }
 
   private void initializePArrayLoopList(PolynomialArray pArray,boolean b) {
        if (workNum==0) {
 //         System.out.println("");
 //         System.out.println("LoopList.initializeList workNum==0");
 //         System.out.println("");
          loadPArray(pArray,b);   
    //      System.out.println("rListB: "+rListB.toString());
      } else {
 //      System.out.println("");
 //      System.out.println("LoopList.initializeList workNum>0 "+workNum);  
 //      System.out.println("");
       subsequentWorkerListInit();   
       
      }
 //    System.out.println("LoopList.initializePArrayLoopList.thisList: "+thisList.toString());
     this.aMatrix.setMatrix(thisList);
 //   System.out.println("LoopList.initializePArrayLoopList rListB: "+rListB.toString());
    }

    private void initializePArrayLoopList(PolynomialArray pArray) {
        if (workNum==0) {
 //         System.out.println("");
 //         System.out.println("LoopList.initializeList workNum==0");
 //         System.out.println("");
          loadPArray(pArray);   
    //      System.out.println("rListB: "+rListB.toString());
      } else {
 //      System.out.println("");
 //      System.out.println("LoopList.initializeList workNum>0 "+workNum);  
 //      System.out.println("");
       subsequentWorkerListInit();   
       
      }
 //    System.out.println("LoopList.initializePArrayLoopList.thisList: "+thisList.toString());
     this.aMatrix.setMatrix(thisList);
 //   System.out.println("LoopList.initializePArrayLoopList rListB: "+rListB.toString());
    
        
    }

    private void initializeTransferLoopList(List transferList) {
        if (workNum==0) {
 //         System.out.println("");
 //         System.out.println("LoopList.initializeList workNum==0");
//          System.out.println("");
          LoadTransferList(transferList);   
    //      System.out.println("rListB: "+rListB.toString());
      } else {
  //     System.out.println("");
  //     System.out.println("LoopList.initializeList workNum>0 "+workNum);  
  //     System.out.println("");
       subsequentWorkerListInit();   
       
      }
//     System.out.println("LoopList.initializeTransferLoopList.thisList: "+thisList.toString());
     this.aMatrix.setMatrix(thisList);
//    System.out.println("LoopList.initializeList rListB: "+rListB.toString());
    
        
    }
      
      
       
    /*it performs the triagTriag subtraction. private method for populating gbList.  needs reference to rList.   
    */
    
    private void subsequentWorkerListInit() {
        
    //iterate over integer range
    // for each integer in range
    // subtract entries at integer of prior looplist
    BigDecimal arg1=new BigDecimal(1); 
    BigDecimal arg2=new BigDecimal(1);
    BigDecimal arg11=new BigDecimal(1); 
    BigDecimal arg22=new BigDecimal(1);
    BigDecimal difference=new BigDecimal(1);
    BigDecimal listResult=new BigDecimal(1);      //result
    BigDecimal listResult1=new BigDecimal(1);
    BigDecimal zero=new BigDecimal(0);
    BigDecimal bigDecimalRange=new BigDecimal(1); // synchronized with x
    BigDecimal bigDecimalDimension=new BigDecimal(dimension);
    BigDecimal one=new BigDecimal(1);
    BigDecimal factordResult=new BigDecimal(1);
    int moduloIndex;
//System.out.println("LoopList.subsequentWorkerListInitWorkNum : "+ancestorlist.toString());
//System.out.println("subsequent deltalist: "+deltaList.toString());
//System.out.println("LoopList.subsequentWorkerListInit.worknum,integerRange: "+workNum+ "  " + integerRange);
//System.out.println("LoopList.subsequentWorkerListInit.rListB1: "+rListB.toString());
for (int x=workNum-1;  x<workNum; x++){    
//  System.out.println("workNum: "+workNum);
//  System.out.println("x: "+x);
 // System.out.println("((LoopList)rListB.get(x)).toString():"+((LoopList)rListB.get(x)).toString());
    for (int y=0;  y<integerRange; y++){
 //    System.out.println("((LoopList)rListB.get(x)).get(y)).toString():"+(((LoopList)rListB.get(x)).get(y)).toString());  
 //    System.out.println("x: "+x+" y: "+y);
     arg1=(BigDecimal)((LoopList)rListB.get(x)).get(y);
 //    arg11=(BigDecimal)((List)ancestorlist.get(x)).get(y);
    // System.out.println("arg1, arg11: "+arg1.toString()+"   "+arg11.toString());
     
     if (y+1<integerRange)
     { 
         arg2=(BigDecimal)((LoopList)rListB.get(x)).get(y+1);
 //        arg22=(BigDecimal)((List)ancestorlist.get(x)).get(y+1);
     }
     else
     {arg2=zero;arg22=zero; }  
     listResult=arg2.subtract(arg1);
//     System.out.println("arg2,arg1: "+arg2.toString()+"  "+arg1);
     //  listResult1=arg22.subtract(arg11);
   //  difference=listResult.subtract(listResult1);
    moduloIndex=workNum-1;
//     System.out.println("listResult, moduloIndex: "+listResult.toString()+"  "+moduloIndex);
//     System.out.println("moduloList: "+moduloList.toString()); 
//  try {  //System.out.println("modulo value: "+(BigDecimal)moduloList.get(moduloIndex)); 
//   try {
//     factordResult=listResult.divide((BigDecimal)moduloList.get(moduloIndex));
//   } catch (ArithmeticException exx) {factordResult=listResult; }
//   }
//  catch (NullPointerException ex) {
//     System.out.println(ex); 
//  }
//    this.
 
 //    ((List)deltaList.get(workNum)).add(difference);
     this.add(listResult);thisList.add(listResult);
 //    ((List)ancestorlist.get(workNum)).add(listResult1);
 //    this.ancestorTerm.add(listResult1);
    }   
    }
 //   System.out.println("subsequentWorkerListInit.this: "+this.toString());
//    System.out.println("subsequent this: "+this.toString());
//    rListB.add(this);
//     cashedrListB.add(this);
 //    ((List)ancestorlist.get(workNum)).add(listPower1);
 //    this.ancestorlist.add(ancestorTerm);
 //    System.out.println("subsequent rListB: "+rListB.toString()); 
    }
       
    
    /* raises each integerRange to power of dimension
    */    
    
    private void firstWorkerListInit()  {
    BigDecimal listPower=new BigDecimal(1);      //result
    
    BigDecimal zero=new BigDecimal(0);
    BigDecimal bigDecimalRange=new BigDecimal(0); // synchronized with x
    BigDecimal bigDecimalDimension=new BigDecimal(dimension);
    BigDecimal one=new BigDecimal(1);
    BigDecimal listPower1=new BigDecimal(1);
    BigDecimal difference=new BigDecimal(1);
  //  this.add(zero);  // place 0^dimension onto looplist
 //  this.ancestorTerm.add(zero);
 //   System.out.println("firstWorkerListInit() workNum: "+workNum);
 //   System.out.println("integerRange: "+integerRange);
    for (int x=0;  x<integerRange; x++){

       listPower=bigDecimalRange.pow(dimension);
       listPower1=bigDecimalRange.pow(dimension+1);
   //    listPower=bigDecimalRange.multiply(bigDecimalDimension);
       difference=listPower1.subtract(listPower);
       ((List)deltaList.get(workNum)).add(difference);
       this.add(listPower);thisList.add(listPower);
       ((List)ancestorlist.get(workNum)).add(listPower1);
   //    this.ancestorTerm.add(listPower1);
       bigDecimalRange=bigDecimalRange.add(one);
    }   
    
//    rListB.add(this);
//    cashedrListB.add(this);
  //  this.ancestorlist.add(this.ancestorTerm);
  //   System.out.println("initial rListB: "+rListB.toString());
  //   System.out.println("initial ancestorlist: "+ancestorlist.toString());
  //   System.out.println("initial deltalist: "+deltaList.toString());
    }
    
     public  static void printMatrix( double[][] A){
     int n = A.length - 1;
     int m = A[0].length - 1;
    
     
     System.out.println();
     for(int i=1; i<=n; i++){
         for(int j=1; j<=m; j++) System.out.print(A[i][j] + "  ");
         System.out.println();
      }
      
      System.out.println();
      System.out.println();
   }

    
    
    
    private void initializeList() {
      
        if (workNum==0) {
 //         System.out.println("");
 //         System.out.println("LoopList.initializeList workNum==0");
 //         System.out.println("");
          firstWorkerListInit();                                            // raises each integerRange to power of dimension
    //      System.out.println("rListB: "+rListB.toString());
      } else {
//System.out.println("");
//       System.out.println("LoopList.initializeList workNum>0 "+workNum);  
//System.out.println("");
       subsequentWorkerListInit();   
       
      }
     this.aMatrix.setMatrix(thisList);
//    System.out.println("LoopList.initializeList thisList: "+thisList.toString());
//    System.out.println("LoopList.initializeList rListB: "+rListB.toString());
//    System.out.println("LoopList.initializeList this.aMatrix.setMatrix: ");
    this.aMatrix.printMatrix();
    }
       
    public MatrixA getAMatrix() {
        return(this.aMatrix);
    }   
   
     public double[][] getAMatrixA() {
        return(this.aMatrix.getA());
    }  
    
   public double[][] getgMatrix() {
        return(this.aMatrix.getgMatrix());
    } 
     
    public int getworkNum() {
        return(workNum);
    } 
     
     
    
    public long getThreadId() {
        return threadId;
    }
    
    public void setThreadId(long value) {
        threadId=value;
    }
    
    
    
    public List getancestorlist() {
        return this.ancestorlist;
    }
            
            
            
    public String getGBList() {
        return this.toString();
    }
    
     public synchronized void setGBList(muNumDen value) {
 //   public synchronized void setGBList(String value) {
 //    propertySupport.firePropertyChange(this.toString(), this, value);
//      System.out.println();
//      System.out.println("LoopList.setGBList (muNumDen)value.getWorkNum: " + value.getWorkNum()+ " " );
//      System.out.println();
         propertySupport.firePropertyChange("abc", "abc", value);
  //      System.out.println(" this.to string" + this.toString()+ " " );
//        System.out.println("                       setGBList fallthrough                    (  propertySupport.firePropertyChange  )                       " );
     }
    
    public void addPropertyChangeListener(PropertyChangeListener listener) {
        propertySupport.addPropertyChangeListener(listener);
    }
    
    public void removePropertyChangeListener(PropertyChangeListener listener) {
        propertySupport.removePropertyChangeListener(listener);
    }

    private void firstdeltaTermInit() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    
    
    }

public void setVmResult(String vmResult){
    this.vmResult=vmResult;
}    
    
public String getVmResult() {
    return(this.vmResult);
}
 


}
