/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LoopLists;

import LoopsLogic.ModuloList;
import PArrayReset.PArrayResetFlag;
import PArrayReset.PolynomialArray;
import PArrayReset.ResultListID;
import fractionintegerset.*;                      //* do not need whole library */
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import static java.lang.System.gc;
import static java.lang.Thread.sleep;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
//import java.util.concurrent.ExecutorService;
//import java.util.concurrent.Executors;
//import java.util.concurrent.Future;
//import java.util.concurrent.Semaphore;

import java.util.concurrent.Callable;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.Semaphore;

import java.lang.management.ManagementFactory;
import java.lang.management.ThreadMXBean;
import java.util.Arrays;




import java.util.logging.Level;
import java.util.logging.Logger;
import mugauss.GaussMain;

/**  There is only one type of 
 *
 * @author HP_Administrator
 */
public class LoopListener implements PropertyChangeListener {

    LoopList gbList;
    ResultListBean rListB;
    ResultListBean allrListB;
    List muList = new ArrayList();
    Semaphore muSem = new Semaphore(1);
    Semaphore listenerRunnableSemaphore = new Semaphore(0);
    ExecutorService exec;
    int rListIndex;
    int updateIncrement;
    int dimension=5;    // artifact, is valued in constructor.
    PolynomialArray pArray;
    ModuloList moduloList;
    List deltaList;
    private BigDecimal rnumber = new BigDecimal(1);
    private BigDecimal one = new BigDecimal(1);
    private BigDecimal devides = new BigDecimal(1);
    private BigDecimal wModulo = new BigDecimal(1);
    private BigDecimal rModulo = new BigDecimal(1);
    private List ancestorlist;
    private GaussMain gMain = new GaussMain();
    private PolynomialArray copyParray;
    private PolynomialArray figPArray;
    private ResultListBean copyRlistB;
    MatrixA xPowers;
    ResultListID resultListId = new ResultListID();
    int resultListCounter=resultListId.getrListId();;
    private PArrayResetFlag pArrayResetFlag;
    final ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
    ExecutorService executorService1 = Executors.newFixedThreadPool(50);                                       //  get these out of the propertychange method
    CompletionService<String> service = new ExecutorCompletionService<>(executorService1);                      // get these out of the property change method
    ResultListBean cashedrListB; 
    PolynomialArray cashedPArray;    // 
    PolynomialArray cashedFigPArray;
 

    
    public LoopListener(ResultListBean allrListB,int dimension,ResultListBean rListB, LoopList gbList, List muList, Semaphore muSem, ExecutorService exec, int rListIndex, PolynomialArray pArray, ModuloList moduloList,List deltaList,List ancestorlist,PolynomialArray figPArray,PArrayResetFlag pArrayResetFlag,ResultListBean cashedrListB,PolynomialArray cashedPArray,PolynomialArray cashedFigPArray,    ResultListID resultListId ) {
        this.allrListB=allrListB;
        this.dimension=dimension;
        this.gbList = gbList;
        this.muList = muList;
        this.muSem = muSem;
        this.exec = exec;
        this.rListIndex = rListIndex;        //  must rename and refactor.   rListIndex is really the size of rListB.  
        this.pArray = pArray;
        this.moduloList = moduloList;
        this.rListB=rListB;
        this.deltaList=deltaList;
        this.ancestorlist=ancestorlist;
        this.figPArray=figPArray;
        this.pArrayResetFlag=pArrayResetFlag;
//        this.cashedrListB=cashedrListB;
        this.cashedrListB=cashedrListB;
        this.cashedPArray=cashedPArray;
        this.cashedFigPArray=cashedFigPArray;
        this.resultListId=resultListId;
        xPowers=new MatrixA(dimension+1);
    }

  
   public void setRlistB(ResultListBean rListB) {
//    System.out.println("LoopListener.setrlistb.to string                                                        before             " +  this.rListB);  
   this.rListB=rListB;
  //      System.out.println("LoopListener.setrlistb.to string                                                     after             " +  this.rListB);    
   }
    
    private BigDecimal setupdateIncrement(BigDecimal wModulo) {
    //    System.out.println("wModulo: " + wModulo.toString() + " rModulo: " + rModulo.toString());
  //setupdateIncrement(rnumber, n, wModulo)   gbList.setGBList(new muNumDen(modulo,workerNum));
    //   try {
        devides = wModulo.divide(rModulo);
   //     }
   //     catch (ArithmeticException ae) {
   //     System.out.println("            ArithmeticException wModulo: " + wModulo.toString() + " rModulo: " + rModulo.toString());   
   //     }
        return (devides);
    }
   
 
/**
 * 
 *  
 */


private void copyRListBValues(int wNum)  {
    List indexList;
    BigDecimal indexValue;
    int integerRange=15;
  //  System.out.println();
  //  System.out.println("  LoopListener.iterateRlistB:" );
     int sizerListB;
    if (resultListId.gethighestWorker()<wNum) {
    
    cashedrListB.clear();
   sizerListB=rListB.size();
    for (int l=0; l<sizerListB;l++)
    {
        indexList=(ArrayList)rListB.get(l);
        cashedrListB.add(indexList);
        //       for (int m=0; m<integerRange; m++)  {
 //       indexValue=(BigDecimal)indexList.get(m);
 //       ((LoopList)cashedrListB.get(l)).set(m,indexValue);
 //       System.out.println("  rlistb.listindex.value:" + indexValue);
 //       }
    }
     resultListId.sethighestWorker(wNum);
    }
//    System.out.println();
}

private void copyFigPArrayValues(int wNum) {
    int value;
    int iterateRange=dimension;
   System.out.println("LoopListener.copyFigPArrayValues cashedFigPArry,figParray"+cashedFigPArray.toString()+ "  "+ figPArray.toString());
  
  
    if (resultListId.gethighestWorker()<wNum) {
   for (int l=0; l<wNum;l++) {
     //   value=(int)figPArray.get(l);
        cashedFigPArray.set(l, 0);
    }
   
    for (int l=(wNum+1); l<iterateRange;l++) {
        value=(int)figPArray.get(l);
        cashedFigPArray.set(l, value);
    }
    } 
    System.out.println("LoopListener.copyFigPArrayValues cshedfigpArray, figParray"+cashedFigPArray.toString()+ "  "+ figPArray.toString()); 
}




private synchronized void pArrayIncrement(PropertyChangeEvent evt)  {
     
//     ResultListBean rListB1 =new ResultListBean();
 int wNum=((muNumDen) evt.getNewValue()).getWorkNum();
 //    System.out.println();
 //    System.out.println("LoopListener.pArrayIncrement pArray .to string " + pArray.toString() + " " + "wNum: " + wNum + "  rListIndex: "+ rListIndex);   
     if (!pArrayResetFlag.getPArrayReset()) {pArray.incrementP(rListIndex - 2);}
    System.out.println("LoopListener.pArrayIncrement pArray .to string " + pArray.toString() + " " + "wNum: " + wNum + "  rListIndex: "+ rListIndex);     
 //    System.out.println();
     if (pArrayResetFlag.getPArrayReset()) {
         System.out.println("                              pArrayResetFlag!!!!!!!!!!!!!!!!!!!!!!!!!");   
         pArrayResetFlag.setPArrayReset();
          copyFigPArrayValues(wNum);
         copyRListBValues(wNum);                                              //        cashedrListB=(ResultListBean)rListB.clone();
         copyFigPArrayValues(wNum);                                           // cashedFigPArray=(PolynomialArray)figPArray.clone();
//         System.out.println("                              pArrayResetFlag!!!!!!!!!!!!!!!!!!!!!!!!cashedFigPArray!"   + cashedFigPArray.toString());   
     }
    }
    
     private int evalCoeff(int index, int scalar, int denumerator)  {
     int result=1;
     for (int k = 0; k < denumerator; k++)  {  
      result=result*index;   
     }   
     result=result*scalar;
     return(result);
   }

 /**
  * Each value on LoopList arguments figPArray[constant] for a quadratic with roots.
  * it is a hybrid of .appendMuBuffer() and .updateRlistB().
  * @param wZero 
  */
     
 private void verticalTranslateWZero(LoopList wZero ) {
   PolynomialArray figPArrayTranslate=null;
   int wZeroValue;
   int newConstant;
//   BigDecimal one= new BigDecimal(1);
   int len=wZero.size();
   figPArrayTranslate=(PolynomialArray)figPArray.clone();
   System.out.println("LoopListner.verticalTranslateWZero figPArrayTranslate: "+figPArrayTranslate.toString());
   System.out.println("LoopListner.verticalTranslateWZero figPArrayTranslate: "+figPArrayTranslate.toString());
   System.out.println("LoopListner.verticalTranslateWZero figPArray: "+figPArray.toString());
   System.out.println("LoopListner.verticalTranslateWZero looplist: "+wZero.toString());
//  for (int index=0;index<3;index++) {
   for (int index=0;index<len;index++) {
 //      resultListCounter=resultListId.getrListId();
       wZeroValue=((BigDecimal)wZero.get(index)).intValue();
       System.out.println("LoopListner.verticalTranslateWZero index: "+index);
       System.out.println("LoopListner.verticalTranslateWZero wZeroValue: "+wZeroValue);
       newConstant=(int)figPArray.get(0)-wZeroValue;
       figPArrayTranslate.set(0, newConstant);
       System.out.println("LoopListner.verticalTranslateWZero newfigPArrayTranslate: "+figPArrayTranslate.toString());

       this.rListB.clear();
       LoopList gbList00 = new LoopList(dimension+1,rListB,dimension,15,0,xPowers,figPArrayTranslate,moduloList);
       rListB.add(gbList00);
       gMain.gauss(muList,muSem,dimension+1,dimension+2,(double[][])gbList00.getgMatrix(),new GaussBean1(figPArrayTranslate, pArray.toString()  ,gbList00,resultListCounter));       
       for (int numerator=1; numerator<=(dimension) ; numerator++) {
          LoopList gbList01 = new LoopList(dimension-(numerator-1),rListB,dimension,15,numerator,xPowers,figPArrayTranslate,moduloList);    
          rListB.add(gbList01);
        gMain.gauss(muList,muSem,dimension-(numerator-1),dimension-(numerator-1)+1,(double[][])gbList01.getgMatrix(),new GaussBean1(figPArrayTranslate,pArray.toString(),gbList01,resultListCounter));
       }       
       int lenn=rListB.size();
          for (int indexx=0;indexx<lenn;indexx++) {
       GaussBean1 gB1=new GaussBean1(figPArrayTranslate,pArray.toString(),((LoopList)rListB.get(indexx)),resultListCounter); 
       synchronized(this) {   //latest thread issue  numerator should be 1 (the first element on rListB
       muList.add(new GaussBean1(figPArrayTranslate,pArray.toString(),((LoopList)rListB.get(indexx)),resultListCounter));
       //  System.out.println("  new gauss bean    new gauss bean");
       muSem.release();
      }    
   }
       
       
       //GaussBean1 gB1=new GaussBean1(figPArray,pArray.toString(),((LoopList)rListB.get(index)),resultListCounter); 
      // synchronized(this) {   //latest thread issue  numerator should be 1 (the first element on rListB
      // muList.add(new GaussBean1(figPArray,pArray.toString(),((LoopList)rListB.get(index)),resultListCounter));
      // //  System.out.println("  new gauss bean    new gauss bean");
      // muSem.release();
      //}    
   } 
}    
     
 /**  Really  want an executor for the vertical translation.  have one in zad, the origonal.     
  * In java land, if verticalTranslatWzero was in beginning of method, rListB would be senseless later on.
 */    
   private void appendMuBuffer() {
   int len=rListB.size();
   System.out.println("LoopListener.appendMuBuffer pArray " + pArray.toString() + " " + "figPArray: " + figPArray.toString()+ "  rListIndex: "+ rListIndex);  

   for (int index=0;index<len;index++) {
   GaussBean1 gB1=new GaussBean1(figPArray,pArray.toString(),((LoopList)rListB.get(index)),resultListCounter); 
       synchronized(this) {   //latest thread issue  numerator should be 1 (the first element on rListB
       muList.add(new GaussBean1(figPArray,pArray.toString(),((LoopList)rListB.get(index)),resultListCounter));
       //  System.out.println("  new gauss bean    new gauss bean");
       muSem.release();
      }    
   }   
     verticalTranslateWZero(((LoopList)rListB.get(0)));
   } 
    
    /**  differences, factors and gausses the .computIndexZero updated figParray.
     *   this is the task for the appendMuBuffer executor..
     */
   
    private synchronized void updateRlistB() {
      this.rListB.clear();
//      resultListCounter=resultListId.getrListId();
      System.out.println("LoopListener.updateRlistB.figPArray: "+figPArray.toString());
     LoopList gbList00 = new LoopList(dimension+1,rListB,dimension,15,0,xPowers,figPArray,moduloList);
     System.out.println("LoopListener.updateRlistB.gbList00: "+gbList00.toString());
//     LoopList gbListTest = new LoopList(dimension+1,rListB,dimension,15,0,xPowers,figPArray,moduloList);
      rListB.add(gbList00);
     
 //        gMain.gauss(dimension,dimension+1,muSem,(double[][])gbListTest.getgMatrix());
      //  this following used to have dimension,dimension+1
      gMain.gauss(muList,muSem,dimension+1,dimension+2,(double[][])gbList00.getgMatrix(),new GaussBean1(figPArray, pArray.toString()  ,gbList00,resultListCounter));
     for (int numerator=1; numerator<=(dimension) ; numerator++) {
          LoopList gbList01 = new LoopList(dimension-(numerator-1),rListB,dimension,15,numerator,xPowers,figPArray,moduloList);    
          System.out.println("LoopListener.updateRlistB.gbList01: "+gbList01.toString());
          rListB.add(gbList01);
      gMain.gauss(muList,muSem,dimension-(numerator-1),dimension-(numerator-1)+1,(double[][])gbList01.getgMatrix(),new GaussBean1(figPArray,pArray.toString(),gbList01,resultListCounter));
     }   
         System.out.println("LoopListener.updateRlistB  fallthrough.");
    }


private synchronized void factorGBList(LoopList transferList,BigDecimal rModulo)  {
    BigDecimal term;
    for (int index=0; index<transferList.size() ; index++) {
    term=(BigDecimal)transferList.get(index);
   try{
    term=term.divide(rModulo);
    transferList.set(index, term);
  }
  catch (ArithmeticException ae){
 }
  }    
    
}
    
    
private void copyCashedRListBValues()  {
    LoopList indexList;
    List rIndexList;
    BigDecimal indexValue;
    int integerRange=15;
    int sizeList;
    int sizeRange;
    int rSizeRange;
 //   System.out.println();
 //   System.out.println("  LoopListener.copyCashedRListBValues:" );
    sizeList=cashedrListB.size();
    int rSizeList=rListB.size();
//        System.out.println("  LoopListener.copyCashedRListBValues isizeList,rListBSizelist:: "+sizeList + "  "+ rSizeList);
  rListB.clear();
        for (int l=0; l<(sizeList);l++)
    {
  //   MatrixA testMatrixCopy = new MatrixA(gbList.getAMatrix());
//   LoopList testCopyGBlist = new LoopList(gbList,cashedrListB);
//   System.out.println("cashedrListB: "+ cashedrListB.toString());
        indexList=(LoopList)cashedrListB.get(l);
        rListB.add(new LoopList(indexList,cashedrListB));
        //rIndexList=(ArrayList)rListB.get(l);
       // sizeRange=indexList.size();
       // rSizeRange=rIndexList.size();
  //              System.out.println("  LoopListener.isizeRange, rlistB size range: "+sizeRange + "  " +rSizeRange);
//        for (int m=0; m<sizeRange; m++)  {
//      System.out.println("  LoopListener.l, m: "+l+"  "+m );
//            indexValue=(BigDecimal)indexList.get(m);
//        ((LoopList)rListB.get(l)).set(m,indexValue);
//        System.out.println("  rlistb.listindex.value:" + indexValue);
//        }
    }
    System.out.println("LoopListener.copyCashedRListBValues(): "+rListB.toString());
}

private void copyCashedFigPArrayValues() {
    int value;
    int iterateRange=cashedFigPArray.size();
    for (int l=0; l<iterateRange;l++) {
//        System.out.println("LoopListener.copyCahedFigPArrayValues l:" +l);
        value=(int)cashedFigPArray.get(l);
        figPArray.set(l, value);
    }
    System.out.println(" LoopListener.copyCahedFigPArray   figPArray,cashedFigPArray:" +figPArray.toString()+" "+cashedFigPArray.toString());
}


//* .computeIndexZero gets the delta_currentworker polynomial and arguments it with
  /*                pArray_currentworker index value.                                    // Peform the subtraction.
  /*                The result is added to figParray.
  */
     
    private void computeIndexZero (int n,BigDecimal rModulo)  {  // n is wcount worker count from max to 1
     double currentCoefficient=0;
     double [][] A;
     int denumerator;
     int result=0;
     int currentFigPArrayIndexValue;
     int newFigPArrayIndexValue;
     int intModulo;
     System.out.println("LoopListener.computIndexZero.n: " + n + " rModulo: "+rModulo+" cashedFigPArray: "+cashedFigPArray.toString());
     A=((LoopList)rListB.get(n)).getgMatrix(); 
     LoopList.printMatrix(A);
     System.out.println("LoopListener.computIndexZero.A: "+" cashedFigPArray: "+cashedFigPArray.toString()  ); 
     int i = A.length - 1;
     int j = A[0].length - 1; 
     for (int k = 0; k < (i); k++)  {
     System.out.println("LoopListener.computIndexZero.k: " + k + " i: "+i+" cashedFigPArray: "+cashedFigPArray.toString());    
     denumerator=(i-1)-k;
     currentCoefficient=A[k+1][j];
     result=result+evalCoeff(pArray.getpValue(n),(int)Math.rint(currentCoefficient),denumerator);
     System.out.println("LoopListener.computIndexZero.result: "+result+" cashedFigPArray: "+cashedFigPArray.toString()  ); 
     }
      intModulo=rModulo.intValue();
      currentFigPArrayIndexValue=figPArray.getpValue(n);         // currentFigPArrayIndexValue=figPArray.getpValue(n-1);   //  suspect pArrayIndexValue if w=1 it indexes zero  is wrong change index to n
      result=result/intModulo;
      newFigPArrayIndexValue=currentFigPArrayIndexValue-result;
      System.out.println("LoopListener.computIndexZero.figPArray (before): " +figPArray.toString() + " pArray: " + pArray.toString()+" cashedFigPArray: "+cashedFigPArray.toString() ); 
      figPArray.set(n,newFigPArrayIndexValue);
//      figPArray.set(n, newFigPArrayIndexValue);    // figPArray.set(n-1, newFigPArrayIndexValue);             //  suspect pArrayIndexValue if w=1 it indexes zero  is wrong change index to n
      System.out.println("LoopListener.computIndexZero.figPArray,cashedFigPArray (after): " +figPArray.toString()+" "+ cashedFigPArray.toString());  
    }

    
    



    @Override
 /**
 *  With each gbList in subset 1..workerNumber on rListB  .
 * @author HP_Administrator
 */  
public void propertyChange(PropertyChangeEvent evt) {
       gc();
       System.out.println("LoopListener.propertyChange figPArray,cashedFigPArray: "+figPArray.toString()+" "+cashedFigPArray.toString());
       rModulo = (BigDecimal) moduloList.get(((muNumDen)evt.getNewValue()).getWorkNum());  
       int wNum=((muNumDen) evt.getNewValue()).getWorkNum();                                                                     // wNum is now a loop from high to low.
       if (pArrayResetFlag.getPArrayReset()) {                                                                              // loose this condition in recursive.
         pArray.incrementP(rListIndex - 2);
       }
       System.out.println("LoopListener.propertyChange.wNum: "+wNum);
       for (int wCount=(dimension-1); wCount>0; wCount--) { 
     rModulo=(BigDecimal)moduloList.get(wCount-1);
     computeIndexZero(wCount,rModulo);
      updateRlistB();                                                 //  it does clear rListB
     } 
     appendMuBuffer();
     resultListCounter=resultListId.getrListId();
     wModulo = ((muNumDen) evt.getNewValue()).getModulo();
     copyCashedRListBValues();
     copyCashedFigPArrayValues();
     pArrayIncrement(evt);
     System.out.println("                                                       LoopListener.propertyChnge Exit. "); 
    }

}
